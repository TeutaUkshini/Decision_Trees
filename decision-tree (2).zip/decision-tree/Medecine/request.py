import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'age':2, 'gender':9, 'BP':6, 'Cholesterol':3, 'natok':23})

print(r.json())